$(document).bind("mobileinit", function(){
  $.mobile.defaultPageTransition = 'slide';
  $.mobile.page.prototype.options.addBackBtn = true;
});